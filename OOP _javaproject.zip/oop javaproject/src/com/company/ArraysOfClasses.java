package com.company;
import java.util.ArrayList;
public class ArraysOfClasses {
 public static ArrayList<student> students=new ArrayList<>(new ArrayList<>());
   public static ArrayList<doctor>doctors=new ArrayList<>(new ArrayList<>());
   public static ArrayList<technicans> technicans =new ArrayList<>(new ArrayList<>());
   public static ArrayList<employee>employees=new ArrayList<>(new ArrayList<>());
    public static ArrayList<administrators>administrators=new ArrayList<>(new ArrayList<>());
}
