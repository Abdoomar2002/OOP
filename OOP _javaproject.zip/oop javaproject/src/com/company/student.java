package com.company;
public class student extends person {
private int level;
private double x;
private  String depart;

    //x , level,name,age,id,depart
    public student(int level,String name,String name2,String dpart,double gpa,int age,int id ) {
        super(name,name2, id, age);
        this.level = level;
        this.x = gpa;
        this.depart = dpart;
    }

    public student() {
        super();
        this.level = 0;
        this.x = 0.0;
        this.depart = null;
    }

    public String getDepart() {
        return depart;
    }

    public void setDepart(String depart) {
        this.depart = depart;
    }

    public void setX(double x) {
        this.x = x;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public double getGpa() {
        return x;
    }

    @Override
    public void print() {
        super.print();
        String f=String.valueOf(level);
    String h=String.valueOf(x);
        System.out.print(level+methods.Setw(f)+x+methods.Setw(h)+depart+methods.Setw(depart));
    }

    @Override
    public int Edit() {
        int i= super.Edit();
        if (i==1)return 1;
        if (i==4) {
            this.level = sc.nextInt();
          return 1;
        }else if(i==5){this.x=sc.nextInt();
          return 1;
        }else if(i==6){this.depart=sc.next();return 1;
        }else return 0;}

    @Override
    public int display2(double x, int key) {
        key= super.display2(x, key);
        if(key==2) {
            if (x == level)
                print();
        }else if(key==2)
            if(x==this.x)
                print();
             return 0;
    }
}
