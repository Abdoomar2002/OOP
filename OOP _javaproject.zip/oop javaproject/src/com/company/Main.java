package com.company;
import java.util.Scanner;
public class Main {
    public static void main(String[] args)  {
        ArraysOfClasses project =new ArraysOfClasses();
        project.students.add(new student());
        project.doctors.add(new doctor());
        project.administrators.add(new administrators ());
        project.technicans.add(new technicans());
        project.employees.add(new employee());
        project.students.add(new student(1,"Omar","Maher","IT",3.4,19,134));
        project.students.add(new student(2,"Tamer","Baseem","Is",3.6,20,135));
        project.students.add(new student(3,"Ahmed","Mohamed","It",2.4,21,172020));
        project.students.add(new student(4,"Omar","Ahmed","Cs",3.5,23,172030));
        project.students.add(new student(2,"Ahmed","Ali","IT",3.5,19,123));
        project.students.add(new student(2,"abdelrahman","omar","IT",3.58,19,125));
        project.students.add(new student(2,"Mohamed","khaled","IT",3.0,19,124));
        project.students.add(new student(2,"Shaimaa","Ali","IT",3.5,19,126));
        project.students.add(new student(2,"toson","Abdelwahab","IT",3.5,19,127));
        project.students.add(new student(2,"shaimaa","saber","IT",3.5,19,128));
        project.students.add(new student(2,"hamad","Ayman","IT",3.5,19,129));
        project.employees.add(new employee("Ashraf","samy",145,28,"it"));
        project.employees.add(new employee(" Rasha","Alaa",125,25,"is"));
        project.employees.add(new employee ("Alaa","Eid",123001,46,"It"));
        project.employees.add(new employee ("Osama","omar",123002,46,"CS"));
        project.employees.add(new employee ("Alaa","hassan",123004,40,"It"));
        project.employees.add(new employee ("Osama","omar",123005,41,"CS"));
        project.employees.add(new employee("Hamdy"," Salah",123,34,"Is") );
        project.employees.add(new employee("Ali","Reda",122,32,"IT") );
        project.doctors.add(new doctor("Magdy"," Yacoup" ,20001,56,2,"Math 1"));
        project.doctors.add(new doctor("Hassan","Eslam",20002,50,2,"physics 1"));
        project.doctors.add(new doctor("Mostafa", "Kamel",3452,35,2,"oop"));
        project.doctors.add(new doctor("Bahi"," Khalil",1239,55,3,"Math 2"));
        project.doctors.add(new doctor("Marwan","Hassan",1237,45,2,"Phsics2"));
        project.doctors.add(new doctor("Ibrahim","Saad",2563,50,2, "project management"));
        project.administrators.add(new administrators("Osama","sayed",52556,55,"is","representative","data Science"));
        project.administrators.add(new administrators("Abdlrahman","Hassan",54258,60,"Cs","representative","java script"));project.administrators.add( new administrators("Khaled ","fathi",10101,50,"IT" ,"3amid","Network"));
        project.administrators.add( new administrators("Noha","Hussain",10102,50,"IS" ,"3amid ","c++"));
        project.administrators.add( new administrators("islam","Hussan",10105,36,"IT" ,"coDirector ","IS201"));
        project.administrators.add(new administrators("Ahmed","Adel",155,55,"IT","Dean of the College","Network") );
        project.administrators.add(new administrators("Amer","Mousa",165,57,"Cs","College agent","paithon") );
        project.technicans.add(new technicans("Ahmed","hosny",254,25,"Cs","oop"));
        project.technicans.add(new technicans("Ahmed","Abdlrahman",2258,27,"it", "discreet Mathematics"));
        project.technicans.add( new technicans ("sahar","ali",1001,24,"IT" ,"Java"));
        project.technicans.add( new technicans ("Rasha","mostafa",1002,27,"IT" ,"project management"));
        project.technicans.add( new technicans ("Nada","Ahmed",1223,27,"IT" ,"Java Script"));
        project.technicans.add( new technicans ("Marwan","Eid",1224,28,"Cs","oop"));
        int u=1,p=1,l=1,a=1,y=1;
        boolean x=false;

        System.out.println("Welcome to my program ");
        System.out.println("This program  enable you to know the information about our faculty of fci  ");
        System.out.println("Chose the number for the information that you need to know ");
        System.out.println("Hint the password is 12345678\n");
        while (u!=0) {
            System.out.println("1- The information about the administrators");
            System.out.println("2- The information about the doctors");
            System.out.println("3- The information about the technicals");
            System.out.println("4- The information about the employees");
            System.out.println("5- The information about the students");
            System.out.println("0 to end");
            Scanner sc = new Scanner(System.in);
            int getter = sc.nextInt();
            switch (getter) {
                case 1: {
                    System.out.println("Enter the administrators password ");
                    int password;
                    do {
                        System.out.println("Enter correct password, 1 to back step or 0 to end");
                        password = sc.nextInt();
                    } while (password != 12345678&&password!=0&&password!=1);

                    if (password == 12345678&&password!=0&&password!=1) {
                        p=1;
                        while(p!=0) {
                            System.out.println("1- Displaying all the members in the faculty  ");
                            System.out.println("2- Searching about all members in the faculty ");
                            System.out.println("3- Adding a person to the faculty database");
                            System.out.println("4- Editing a person information in the faculty database");
                            System.out.println("5- Removing a person from faculty database");
                            System.out.println("6 to back step");
                            System.out.println("0 to end");
                            int i = sc.nextInt();
                            l=1;
                            while (l != 0) {
                                switch (i) {
                                    case 1: {
                                        System.out.println("1- Display all the administrators");
                                        System.out.println("2- Display all the doctors");
                                        System.out.println("3- Display all the technicals");
                                        System.out.println("4- Display all the employees");
                                        System.out.println("5- Display all the students");
                                        System.out.println("6 to back step");
                                        System.out.println("0 to end");
                                        int getter2 = sc.nextInt();
                                        a = 1;
                                            switch (getter2) {
                                                case 1: {
                                                    System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"psoition"+methods.Setw("position")+"courses");
                                                    for (int j = 1; j < project.administrators.size(); j++) {
                                                        methods.display(project.administrators.get(j));
                                                    }
                                                    System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                                    a = sc.nextInt();
                                                    break;
                                                }
                                                case 2: {
                                                    System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"level"+methods.Setw("level")+"courses");

                                                    for (int j = 1; j < project.doctors.size(); j++) {
                                                        methods.display(project.doctors.get(j));
                                                    }
                                                    System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                                    a = sc.nextInt();
                                                    break;
                                                }
                                                case 3: {
                                                    System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"courses");

                                                    for (int j = 1; j < project.technicans.size(); j++) {
                                                        methods.display(project.technicans.get(j));
                                                    }
                                                    System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                                    a = sc.nextInt();
                                                    break;
                                                }
                                                case 4: {
                                                    System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"depart"+methods.Setw("depart"));

                                                    for (int j = 1; j < project.employees.size(); j++) {
                                                        methods.display(project.employees.get(j));
                                                    }
                                                    System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                                    a = sc.nextInt();
                                                    break;
                                                }
                                                case 5: {
                                                    System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"level"+methods.Setw("level")+"gpa"+methods.Setw("gpa")+"depart");

                                                    for (int j = 1; j < project.students.size(); j++) {
                                                        methods.display(project.students.get(j));
                                                    }
                                                    System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                                    a = sc.nextInt();
                                                    break;
                                                }
                                                case 6: {
                                                    a = 2;
                                                    break;
                                                }
                                                case 0: {
                                                    u = 0;
                                                    a = 0;
                                                    break;
                                                }
                                                default: {
                                                    System.out.println("you input wrong value5");
                                                    getter2 = sc.nextInt();
                                                    break;
                                                }
                                            }
                                            while (a > 2 || a < 0) {
                                                if (a == 1 || a == 2 || a == 0) break;

                                                else {
                                                    System.out.println("wrong input4,");
                                                    a = sc.nextInt();
                                                }
                                            }
                                            if (a == 0) {
                                                l = 0;
                                                p = 0;
                                                u = 0;
                                                break;
                                            } else if (a == 1) {
                                                continue;
                                            } else {
                                                l = 2;
                                                break;
                                            }

                                    }
                                    case 2: {
                                        System.out.println("1- Searching about an administrator");
                                        System.out.println("2- Searching about a doctor");
                                        System.out.println("3- Searching about a technical");
                                        System.out.println("4- Searching about an employee");
                                        System.out.println("5- Searching about a student");
                                        System.out.println("6 to back step");
                                        System.out.println("0 to end");
                                        int getter3 = sc.nextInt();
                                           a=1;
                                        while (a != 0) {
                                            switch (getter3) {
                                                case 1, 2, 3, 4, 5: {
                                                    methods.search(project, getter3);
                                                    System.out.println("if you wants try again press 1\n2 to back step \n0to end");
                                                    a = sc.nextInt();
                                                    break;
                                                }
                                                case 6: {
                                                    a = 2;
                                                    break;
                                                }
                                                case 0: {
                                                    a = 0;
                                                    u = 0;
                                                    break;
                                                }
                                                default: {
                                                    System.out.println("you input wrong value5");
                                                    getter3 = sc.nextInt();
                                                    break;
                                                }
                                            }
                                            while (a > 2 || a < 0) {
                                                if (a == 1 || a == 2 || a == 0) break;

                                                else {
                                                    System.out.println("wrong input4,");
                                                    a = sc.nextInt();
                                                }
                                            }
                                            if (a == 0) {
                                                l = 0;
                                                p = 0;
                                                u = 0;
                                                break;
                                            } else if (a == 1) {
                                                break;
                                            } else {
                                                l = 2;
                                                break;
                                            }

                                        }
                                        break;
                                    }
                                    case 3: {
                                        System.out.println("1- Adding an administrator");
                                        System.out.println("2- Adding a doctor");
                                        System.out.println("3- Adding a technical");
                                        System.out.println("4- Adding an employee");
                                        System.out.println("5- Adding an student");
                                        System.out.println("6 to back step");
                                        System.out.println("0 to end");
                                        int getter4 = sc.nextInt();
                                        a=1;
                                        while (a != 0) {
                                            switch (getter4) {
                                                case 1, 2, 3, 4, 5: {
                                                    methods.add(project, getter4);
                                                    System.out.println("if you wants try again press 1\n2 to back step \n0to end");
                                                    a = sc.nextInt();
                                                    break;
                                                } case 6:{a=2;break;}
                                                case 0:{a=0;u=0;break;}
                                                default: {
                                                    System.out.println("you input wrong value5");
                                                    getter4 = sc.nextInt();
                                                    break;
                                                }
                                            }
                                            while (a > 2 || a < 0) {
                                                if (a == 1 || a == 2 || a == 0) break;

                                                else {
                                                    System.out.println("wrong input4,");
                                                    a = sc.nextInt();
                                                }
                                            }
                                            if (a == 0) {
                                                l = 0;
                                                p = 0;
                                                u = 0;
                                                break;
                                            } else if (a == 1) {
                                                break;
                                            } else {
                                                l = 2;
                                                break;
                                            }
                                        }
                                        break;
                                    }
                                    case 4: {
                                        System.out.println("1- Editing an administrator");
                                        System.out.println("2- Editing a doctor");
                                        System.out.println("3- Editing a technical");
                                        System.out.println("4- Editing an employee");
                                        System.out.println("5- Editing a student");
                                        System.out.println("6 to back step");
                                        System.out.println("0 to end");
                                        int getter5 = sc.nextInt();
                                        a=1;
                                        while (a != 0) {
                                            int j = 0;
                                            j = methods.search(project, getter5);
                                            switch (getter5) {
                                                case 1: {
                                                    a = methods.edit(project.administrators.get(j));
                                                    break;
                                                }
                                                case 2: {
                                                    a = methods.edit(project.doctors.get(j));
                                                    break;
                                                }
                                                case 3: {
                                                    a = methods.edit(project.technicans.get(j));
                                                    break;
                                                }
                                                case 4: {
                                                    a = methods.edit(project.employees.get(j));
                                                    break;
                                                }
                                                case 5: {
                                                    a = methods.edit(project.students.get(j));
                                                    break;
                                                } case 6:{a=2;break;}
                                                case 0:{a=0;u=0;}
                                                default: {
                                                    System.out.println("you input wrong value5");
                                                    getter5 = sc.nextInt();
                                                    break;
                                                }
                                            }
                                            while (a > 2 || a < 0) {
                                                if (a == 1 || a == 2 || a == 0) break;

                                                else {
                                                    System.out.println("wrong input4,");
                                                    a = sc.nextInt();
                                                }
                                            }
                                            if (a == 0) {
                                                l = 0;
                                                p = 0;
                                                u = 0;
                                                break;
                                            } else if (a == 1) {
                                                break;
                                            } else {
                                                l = 2;
                                                break;
                                            }

                                        }
                                        break;
                                    }
                                    case 5: {
                                        System.out.println("1- Removing an administrator");
                                        System.out.println("2- Removing a doctor");
                                        System.out.println("3- Removing a technical");
                                        System.out.println("4- Removing an employee");
                                        System.out.println("5- Removing a student");
                                        System.out.println("6 to back step");
                                        System.out.println("0 to end");
                                        int inn = sc.nextInt();
                                        a=1;
                                        while (a != 0) {
                                            int j;
                                            j = methods.search(project, inn);
                                            switch (inn) {
                                                case 1, 2, 3, 4, 5: {
                                                    a = methods.remove(project, inn, j);
                                                    break;
                                                } case 6:{a=2;break;}
                                                default: {
                                                    System.out.println("you input wrong value5");
                                                    inn = sc.nextInt();
                                                    break;
                                                }
                                            }
                                            while (a > 2 || a < 0) {
                                                if (a == 1 || a == 2 || a == 0) break;

                                                else {
                                                    System.out.println("wrong input4,");
                                                    a = sc.nextInt();
                                                }
                                            }
                                            if (a == 0) {
                                                l = 0;
                                                p = 0;
                                                u = 0;
                                                break;
                                            } else if (a == 1) {
                                                break;
                                            } else {
                                                l = 2;
                                                break;
                                            }

                                        }
                                        break;
                                    }
                                    case 6: {
                                        l = 3;
                                        break;
                                    }
                                    case 0: {l=0;
                                        u = 0;
                                        break;
                                    }
                                    default: {
                                        System.out.println("You entered a wrong chosen ");
                                        i = sc.nextInt();
                                    }
                                }
                                if ( l== 0) {
                                    p=0;
                                    u=0;
                                }else if(l==2){;break;}
                                else if(l==3){p=2;break;}
                            }if(p==0||p==2)break;
                        }    }else if(password==0)  {u=0;break;}else {break;}
                break;}
                case 2: {p=1;
                    while(p!=0){
                    System.out.println("1- Displaying all the members in the faculty  ");
                    System.out.println("2- Searching about all members in the faculty ");
                    System.out.println("3- Adding a person for the faculty database");
                    System.out.println("4- Editing a person from faculty database");
                    System.out.println("5- Removing a person information in the faculty database");
                    System.out.println("6 to back step");
                    System.out.println("0 to end");
                    int getter9 = sc.nextInt();
                    l=1;
                    while (l!=0) {
                        switch (getter9) {
                            //////////////////////////////////////////////////////////////
                            case 1: {
                                System.out.println("1- Display all the adminstrator");
                                System.out.println("2- Display all the doctors");
                                System.out.println("3- Display all the technicals");
                                System.out.println("4- Display all the employees");
                                System.out.println("5- Display all the students");
                                System.out.println("6 to back step");
                                System.out.println("0 to end");
                                int getter6 = sc.nextInt();

                                    switch (getter6) {
                                        case 1:{
                                            System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"psoition"+methods.Setw("position")+"courses");

                                            for (int j = 1; j < project.administrators.size(); j++) {
                                                methods.display(project.administrators.get(j));
                                            }
                                            System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                            a = sc.nextInt();
                                            break;
                                        }
                                        case 2: {
                                            System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"level"+methods.Setw("level")+"courses");

                                            for (int j = 1; j < project.doctors.size(); j++) {
                                                methods.display(project.doctors.get(j));
                                            }
                                            System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                            a = sc.nextInt();
                                            break;
                                        }
                                        case 3: {
                                            System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"courses");

                                            for (int j = 1; j < project.technicans.size(); j++) {
                                                methods.display(project.technicans.get(j));
                                            }
                                            System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                            a = sc.nextInt();
                                            break;
                                        }
                                        case 4: {
                                            System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"depart"+methods.Setw("depart"));

                                            for (int j = 1; j < project.employees.size(); j++) {
                                                methods.display(project.employees.get(j));
                                            }
                                            System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                            a = sc.nextInt();
                                            break;
                                        }
                                        case 5: {
                                            System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"level"+methods.Setw("level")+"gpa"+methods.Setw("gpa")+"depart");

                                            for (int j = 1; j < project.students.size(); j++) {
                                                methods.display(project.students.get(j));
                                            }
                                            System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                            a = sc.nextInt();
                                            break;
                                        }
                                        case 6: {
                                            a = 2;
                                            break;
                                        }
                                        case 0: {
                                            u = 0;
                                            a = 0;
                                            break;
                                        }
                                        default: {
                                            System.out.println("you input wrong value5");
                                            getter6 = sc.nextInt();
                                            break;
                                        }
                                    }

                                    while (a > 2 || a < 0) {
                                        if (a == 1 || a == 2 || a == 0) break;

                                        else {
                                            System.out.println("wrong input4,");
                                            a = sc.nextInt();
                                        }
                                    }
                                    if (a == 0) {
                                        l = 0;
                                        p = 0;
                                        u = 0;
                                        break;
                                    } else if (a == 1) {
                                        break;
                                    } else {
                                        l = 2;
                                        break;
                                    }
                            }
                            case 2: {
//                                System.out.println("1- Searching about an administrators");
                                System.out.println("1- Searching about a doctors");
                                System.out.println("2- Searching about a technicals");
                                System.out.println("3- Searching about an employees");
                                System.out.println("4- Searching about a students");
                                System.out.println("5 to back step");
                                System.out.println("0 to end");
                                int getter6 = sc.nextInt();
                                a=1;
                                while (a != 0) {
                                    switch (getter6) {
                                        case 1, 2, 3, 4: {

                                            methods.search(project, getter6);
                                            System.out.println("if you wants try again press 1\n2 to back step \n0to end");
                                            a = sc.nextInt();
                                            break;
                                        }case 5: {
                                            a = 2;
                                            break;
                                        }
                                        case 0: {
                                            u = 0;
                                            a = 0;
                                            break;
                                        }
                                        default: {
                                            System.out.println("you input wrong value5");
                                            getter6 = sc.nextInt();
                                            break;
                                        }
                                    }

                                    while (a > 2 || a < 0) {
                                        if (a == 1 || a == 2 || a == 0) break;

                                        else {
                                            System.out.println("wrong input4,");
                                            a = sc.nextInt();
                                        }
                                    }
                                    if (a == 0) {
                                        l = 0;
                                        p = 0;
                                        u = 0;
                                        break;
                                    } else if (a == 1) {
                                        break;
                                    } else {
                                        l = 1;
                                        break;
                                    }

                                }
                                break;
                            }
                            case 3: {
                                System.out.println("1- Adding a technical");
                                System.out.println("2- Adding a student");
                                System.out.println("3 to back step");
                                System.out.println("0 to end");
                                int getter7 = sc.nextInt();
                                a=1;
                                while (a != 0) {
                                    switch (getter7) {
                                        case 1, 2: {
                                            if (getter7 == 1)
                                                methods.add(project, 3);
                                            else if (getter7 == 2)
                                                methods.add(project, 5);
                                            System.out.println("if you wants try again press 1\n2 to back step \n0to end");
                                            a = sc.nextInt();
                                            break;
                                        }
                                        case 3: {
                                            a = 2;
                                            break;
                                        }
                                        case 0: {
                                            u = 0;
                                            a = 0;
                                            break;
                                        }
                                        default: {
                                            System.out.println("you input wrong value5");
                                            getter7 = sc.nextInt();
                                            break;
                                        }
                                    }

                                    while (a > 2 || a < 0) {
                                        if (a == 1 || a == 2 || a == 0) break;

                                        else {
                                            System.out.println("wrong input4,");
                                            a = sc.nextInt();
                                        }
                                    }
                                    if (a == 0) {
                                        l = 0;
                                        p = 0;
                                        u = 0;
                                        break;
                                    } else if (a == 1) {
                                        break;
                                    } else {
                                        l = 1;
                                        break;
                                    }

                                }
                                break;
                            }
                            case 4: {
                                System.out.println("1- Editing a technical");
                                System.out.println("2 Editing a student");
                                System.out.println("3 to back step");
                                System.out.println("0 to end");
                                int getter8 = sc.nextInt();
                                a=1;
                                while (a!=0) {
                                    int j = 0;

                                    switch (getter8) {
                                        case 1: {
                                            j = methods.search(project, 3);
                                            if (j==0)break;
                                            a = methods.edit(project.technicans.get(j));
                                            break;
                                        }
                                        case 2: {j = methods.search(project, 5);
                                            if(j==0)break;
                                            a = methods.edit(project.students.get(j));
                                            break;
                                        }case 3:{a=2;break;}
                                        default: {
                                            System.out.println("you input wrong value5");
                                            getter8 = sc.nextInt();
                                            break;
                                        }
                                    }
                                    while (a > 2 || a < 0) {
                                        if (a == 1 || a == 2 || a == 0) break;

                                        else {
                                            System.out.println("wrong input4,");
                                            a = sc.nextInt();
                                        }
                                    }
                                    if (a == 0) {
                                        l = 0;
                                        p = 0;
                                        u = 0;
                                        break;
                                    } else if (a == 1) {
                                        break;
                                    } else {
                                        l = 2;
                                        break;
                                    }

                                }
                                break;
                            }
                            case 5: {
                                System.out.println("1- Removing a technical");
                                System.out.println("2- Removing a  student");
                                System.out.println("3 to back step");
                                System.out.println("0 to end");
                                int getter10 = sc.nextInt();
                                a=1;
                                while (a!=0) {
                                    int j;

                                    switch (getter10) {
                                        case 1:{
                                            j = methods.search(project, 3);
                                            a = methods.remove(project, 3, j);
                                              break;
                                        }
                                        case 2:{
                                                 j = methods.search(project, 5);
                                                    a = methods.remove(project, 5, j);
                                                break;
                                        }case 3:{a=2;break;}
                                        default: {
                                            System.out.println("you input wrong value5");
                                            getter10 = sc.nextInt();
                                            break;
                                        }
                                    }
                                    while (a > 2 || a < 0) {
                                        if (a == 1 || a == 2 || a == 0) break;

                                        else {
                                            System.out.println("wrong input4,");
                                            a = sc.nextInt();
                                        }
                                    }
                                    if (a == 0) {
                                        l = 0;
                                        p = 0;
                                        u = 0;
                                        break;
                                    } else if (a == 1) {
                                        break;
                                    } else {
                                        l = 2;
                                        break;
                                    }

                                }
                                break;
                            }
                            case 6: {
                                l = 3;
                                break;
                            }
                            case 0: {l=0;
                                u = 0;
                                break;
                            }
                            default: {
                                System.out.println("You entered a wrong chosen ");
                                getter9 = sc.nextInt();
                            }
                        }
                        if ( l== 0) {
                            p=0;
                            u=0;
                        }else if(l==2)break;
                        else if(l==3){p=2;break;}
                    }if(p==0||p==2)break;
                    }break;}
                case 3: {p=1;
                    while (p!=0){
                    System.out.println("1- Displaying all the students in the faculty  ");
                    System.out.println("2- Searching about all students in the faculty ");
                    System.out.println("3- Adding a student to the faculty database");
                    System.out.println("4- Editing a student to faculty database");
                    System.out.println("5- Removing a student information from the faculty database");
                    System.out.println("6 to back step");
                    System.out.println("0 to end");
                    int getter11 = sc.nextInt();
                    l=1;
                    while (l!=0) {
                        switch (getter11) {
                            case 1: {
                                System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"level"+methods.Setw("level")+"gpa"+methods.Setw("gpa")+"depart");

                                for (int j = 1; j < project.students.size(); j++) {
                                    methods.display(project.students.get(j));
                                }
                                System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                a = sc.nextInt();
                                break;
                            }
                            case 2: {
                                methods.search(project, 5);
                                System.out.println("if you wants try again press 1\n2 to back step \n0to end");
                                a = sc.nextInt();
                                break;
                            }
                            case 3: {
                                methods.add(project, 5);
                                System.out.println("if you wants try again press 1\n2 to back step \n0to end");
                                a = sc.nextInt();
                                break;
                            }
                            case 4: {
                                int j=methods.search(project,5);
                                a = methods.edit(project.students.get(j));
                                break;
                            }
                            case 5: {
                                int j=methods.search(project,5);
                                a = methods.remove(project,getter11, j);
                                break;
                            } case 6: {
                                l = 3;
                                break;
                            }
                            case 0: {l=0;
                                u = 0;
                                break;
                            }
                            default: {
                                System.out.println("You entered a wrong chosen ");
                                getter11 = sc.nextInt();
                            }
                        }while (a > 2 || a < 0) {
                            if (a == 1 || a == 2 || a == 0) break;

                            else {
                                System.out.println("wrong input4,");
                                a = sc.nextInt();
                            }
                        }
                        if ( l== 0) {
                            p=0;
                            u=0;
                        }else if(l==2)break;
                        else if(l==3){p=2;break;}
                    }if(p==0||p==2)break;
                    }break;}
                case 4: {p=1;
                    while(p!=0){
                    System.out.println("1- Displaying all the members in the faculty  ");
                    System.out.println("2- Searching about all members in the faculty ");
                    System.out.println("3- Adding a student or employee to the faculty database");
                    System.out.println("4- Editing a student or an employee  in faculty database");
                    System.out.println("5- Removing a student or an employee  information from the faculty database");
                    System.out.println("6 to back step");
                    System.out.println("0 to end");
                    int getter12 = sc.nextInt();
                    l=1;
                    while (l!=0) {
                        switch (getter12) {
                            case 1: {
                                System.out.println("1- Display all the administrators");
                                System.out.println("2- Display all the doctors");
                                System.out.println("3- Display all the technicals");
                                System.out.println("4- Display all the employees");
                                System.out.println("5- Display all the students");
                                System.out.println("6 to back step");
                                System.out.println("0 to end");
                                int getter15 = sc.nextInt();
                                a = 1;
                                switch (getter15) {
                                    case 1: {
                                        System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"psoition"+methods.Setw("position")+"courses");

                                        for (int j = 1; j < project.administrators.size(); j++) {
                                            methods.display(project.administrators.get(j));
                                        }
                                        System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                        a = sc.nextInt();
                                        break;
                                    }
                                    case 2: {
                                        System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"level"+methods.Setw("level")+"courses");
                                        for (int j = 1; j < project.doctors.size(); j++) {
                                            methods.display(project.doctors.get(j));
                                        }
                                        System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                        a = sc.nextInt();
                                        break;
                                    }
                                    case 3: {
                                        System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"courses");

                                        for (int j = 1; j < project.technicans.size(); j++) {
                                            methods.display(project.technicans.get(j));
                                        }
                                        System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                        a = sc.nextInt();
                                        break;
                                    }
                                    case 4: {
                                        System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"depart"+methods.Setw("depart"));

                                        for (int j = 1; j < project.employees.size(); j++) {
                                            methods.display(project.employees.get(j));
                                        }
                                        System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                        a = sc.nextInt();
                                        break;
                                    }
                                    case 5: {
                                        System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"level"+methods.Setw("level")+"gpa"+methods.Setw("gpa")+"depart");

                                        for (int j = 1; j < project.students.size(); j++) {
                                            methods.display(project.students.get(j));
                                        }
                                        System.out.println("if you want to try another case press 1\n back step press 2\n,if you want to end press 0");
                                        a = sc.nextInt();
                                        break;
                                    }
                                    case 6: {
                                        a = 2;
                                        break;
                                    }
                                    case 0: {
                                        u = 0;
                                        a = 0;
                                        break;
                                    }
                                    default: {
                                        System.out.println("you input wrong value5");
                                        getter15 = sc.nextInt();
                                        break;
                                    }
                                }
                                while (a > 2 || a < 0) {
                                    if (a == 1 || a == 2 || a == 0) break;

                                    else {
                                        System.out.println("wrong input4,");
                                        a = sc.nextInt();
                                    }
                                }
                                if (a == 0) {
                                    l = 0;
                                    p = 0;
                                    u = 0;
                                    break;
                                } else if (a == 1) {
                                    continue;
                                } else {
                                    l = 2;
                                    break;
                                }

                            }
                            case 2: {
                                System.out.println("1- Searching about an administrator");
                                System.out.println("2- Searching about a doctor");
                                System.out.println("3- Searching about a technical");
                                System.out.println("4- Searching about an employee");
                                System.out.println("5- Searching about a student");
                                System.out.println("6 to back step");
                                System.out.println("0 to end");
                                int getter16 = sc.nextInt();
                                a=1;
                                while (a != 0) {
                                    switch (getter16) {
                                        case 1, 2, 3, 4, 5: {
                                            methods.search(project, getter16);
                                            System.out.println("if you wants try again press 1\n2 to back step \n0to end");
                                            a = sc.nextInt();
                                            break;
                                        }
                                        case 6: {
                                            a = 2;
                                            break;
                                        }
                                        case 0: {
                                            a = 0;
                                            u = 0;
                                            break;
                                        }
                                        default: {
                                            System.out.println("you input wrong value5");
                                            getter16 = sc.nextInt();
                                            break;
                                        }
                                    }
                                    while (a > 2 || a < 0) {
                                        if (a == 1 || a == 2 || a == 0) break;

                                        else {
                                            System.out.println("wrong input4,");
                                            a = sc.nextInt();
                                        }
                                    }
                                    if (a == 0) {
                                        l = 0;
                                        p = 0;
                                        u = 0;
                                        break;
                                    } else if (a == 1) {
                                        break;
                                    } else {
                                        l = 2;
                                        break;
                                    }

                                }
                                break;
                            }
                            case 3: {
                                System.out.println("1- Adding a student ");
                                System.out.println("2- Adding an employee");
                                System.out.println("3 to back step");
                                System.out.println("0 to end");
                                int getter15 = sc.nextInt();
                                a=1;
                                while (a!=0) {
                                    switch (getter15) {
                                        case 1,2: {if(getter15==1)
                                            methods.add(project, 5);
                                            else if (getter15==2)methods.add(project,4);
                                            System.out.println("if you wants try again press 1\n2 to back step \n0to end");
                                            a = sc.nextInt();
                                            break;
                                        }
                                        case 3:{a=2;break;}
                                        case 0:{a=0;u=0;break;}
                                        default: {
                                            System.out.println("you input wrong value5");
                                            getter15 = sc.nextInt();
                                            break;
                                        }
                                    }
                                    while (a > 2 || a < 0) {
                                        if (a == 1 || a == 2 || a == 0) break;

                                        else {
                                            System.out.println("wrong input4,");
                                            a = sc.nextInt();
                                        }
                                    }
                                    if (a == 0) {
                                        l = 0;
                                        p = 0;
                                        u = 0;
                                        break;
                                    } else if (a == 1) {
                                        break;
                                    } else {
                                        l = 2;
                                        break;
                                    }
                                }

                                break;
                            }
                            case 4: {
                                System.out.println("1- Editing a student ");
                                System.out.println("2- Editing an employee");
                                System.out.println("6 to back step");
                                System.out.println("0 to end");
                                int getter16 = sc.nextInt();
                                a=1;
                                while (a!=0) {
                                    int j = 0;

                                    switch (getter16) {
                                        case 2: { j = methods.search(project, 4);if(j==0)break;
                                            a = methods.edit(project.employees.get(j));
                                            break;
                                        }
                                        case 1: { j = methods.search(project, 5);if(j==0)break;
                                            a = methods.edit(project.students.get(j));
                                            break;
                                        }case 3:{a=2;break;}
                                        default: {
                                            System.out.println("you input wrong value5");
                                            getter16 = sc.nextInt();
                                            break;
                                        }
                                    }
                                    while (a > 2 || a < 0) {
                                        if (a == 1 || a == 2 || a == 0) break;

                                        else {
                                            System.out.println("wrong input4,");
                                            a = sc.nextInt();
                                        }
                                    }
                                    if (a == 0) {
                                        l = 0;
                                        p = 0;
                                        u = 0;
                                        break;
                                    } else if (a == 1) {
                                        break;
                                    } else {
                                        l = 2;
                                        break;
                                    }

                                }
                                break;
                            }
                            case 5: {
                                System.out.println("1- Removing a student ");
                                System.out.println("2- Removing an employee");
                                System.out.println("6 to back step");
                                System.out.println("0 to end");
                                int getter17 = sc.nextInt();
                                a=1;
                                while (a!=0) {
                                    int j;

                                    switch (getter17) {
                                        case 1,2: {j = methods.search(project, getter17);if(j==0)break;
                                            if(getter17==2)
                                            a = methods.remove(project, 4, j);
                                            else methods.remove(project,5,j);
                                            break;
                                        }case 3:{a=2;break;}
                                        default: {
                                            System.out.println("you input wrong value5");
                                            getter17 = sc.nextInt();
                                            break;
                                        }
                                    }
                                    while (a > 2 || a < 0) {
                                        if (a == 1 || a == 2 || a == 0) break;

                                        else {
                                            System.out.println("wrong input4,");
                                            a = sc.nextInt();
                                        }
                                    }
                                    if (a == 0) {
                                        l = 0;
                                        p = 0;
                                        u = 0;
                                        break;
                                    } else if (a == 1) {
                                        break;
                                    } else {
                                        l = 2;
                                        break;
                                    }

                                }
                                break;
                            }
                            case 6: {
                                l = 3;
                                break;
                            }
                            case 0: {l=0;
                                u = 0;
                                break;
                            }
                            default: {
                                System.out.println("You entered a wrong chosen ");
                                getter12 = sc.nextInt();
                            }
                        }
                        if ( l== 0) {
                            p=0;
                            u=0;
                        }else if(l==2){;break;}
                        else if(l==3){p=2;break;}
                    }if(p==0||p==2)break;
                    }
                break;}
                case 5: {
                    p=1;
                    while(p!=0){
                    System.out.println("1- Displaying all the students in the faculty  ");
                    System.out.println("2- Searching about a student  in the faculty ");
                    System.out.println("3 to back step");
                    System.out.println("0 to end");
                    int getter17 = sc.nextInt();
                    l=1;
                    while (l!=0) {
                        int j;
                        x=false;
                        switch (getter17) {

                            case 1: {
                                System.out.println("id"+methods.Setw("id")+"full name"+methods.Setw("full name")+"age"+methods.Setw("age")+"level"+methods.Setw("level")+"gpa"+methods.Setw("gpa")+"depart");

                                for (j = 1; j < project.students.size(); j++)
                                        methods.display(project.students.get(j));
                                    System.out.println(" press 1 to back step press \nif you want to end press 0");
                                    a = sc.nextInt();
                                    x = true;
                                break;
                            }
                            case 2: {
                                j = methods.search(project, 5);
                                System.out.println("if you to back step press 1\n2 to try again \n0to end");
                                a = sc.nextInt();
                                break;
                            }
                            case 3: {
                                l = 3;
                                a=2;
                                break;
                            }
                            case 0: {l=0;a=0;
                                u = 0;
                                break;
                            }
                            default: {
                                System.out.println("You entered a wrong chosen ");
                                getter17 = sc.nextInt();
                            }
                        }while (a ==2&&x) {
                            if (a == 1 || a == 0) break;

                            else {
                                System.out.println("wrong input4,");
                                a = sc.nextInt();
                            }
                        }
                        while (a > 2 || a < 0) {
                            if (a == 1 ||( a == 2&&!x) || a == 0) break;

                            else {
                                System.out.println("wrong input4,");
                                a = sc.nextInt();
                            }
                        }
                         if(a==1)l=2;
                        if(a==0){l=0;p=0;u=0;}
                        if ( l== 0) {
                            p=0;
                            u=0;
                        }else if(l==2)break;
                        else if(l==3){p=2;break;}
                    }if(p==0||p==2)break;
                    }break;}
                case 0:{ u=0;
                break;}
                default:{
                    System.out.println("You entered a wrong chosen ");
                    System.out.println("input a valid value");
                break;}

            }

        }
System.out.println("thanks for using my program\n bye bye");

    }}


