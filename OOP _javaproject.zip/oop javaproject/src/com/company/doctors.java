package com.company;
class doctor  extends person {

    private int level;
    private  String x;    // x= courses

    @Override
    public void print() {
        super.print();
        String k=String.valueOf(level);
        System.out.print(level+methods.Setw(k)+x+methods.Setw(x));
    }
    @Override
    public int Edit() {
        int i= super.Edit();
        if (i==1)return 1;
        if (i==5) {
            this.level = sc.nextInt();
            return 1;
        }else if(i==6){this.x=sc.next();
            return 1;
        }else return 0;
}

    public doctor() {
        super();
        this.x=null;
        this.level=0;
    }

    //
    public doctor(String name1,String name2, int id, int age, int level,String x) {
        super(name1,name2, id, age);
        this.level = level;
        this.x=x;
    }

    public void setCourses(String courses) {
        this.x = courses;
    }
    public String getCourses() {

        return x;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getLevel() {
        return level;
    }
}
