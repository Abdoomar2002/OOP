package com.company;
public class employee extends person {

    private String depart;

    public employee() {
        super();
        this.depart=null;
    }

    public employee(String name1,String name2, int id, int age, String depart) {
        super(name1,name2, id, age);

        this.depart = depart;

    }
    public String getDepart() {
        return depart;
    }
    public void setDepart(String depart) {
        this.depart = depart;
    }
    @Override
    public void print() {
        super.print();
        System.out.print(depart+methods.Setw(depart));
    } public int Edit() {
        int i= super.Edit();
        if (i==1)return 1;
        if (i==4) {
            this.depart = sc.next();
            return 1;
        }else return i;}
}

