package com.company;
public class administrators extends employee {
    private String position;
    private String courses;

    public administrators() {
        super();
        this.courses=null;
        this.position=null;
    }
    public administrators(String name1,String name2, int id, int age, String depart, String position, String courses) {
        super(name1,name2, id, age, depart);
        this.position = position;
        this.courses = courses;
    }
    public void setCourses(String courses) {
        this.courses = courses;
    }
    public String getCourses() {
        return courses;
    }
    public String getPosition() {
        return position;
    }
    public void setPosition(String position) {
        this.position = position;
    }
    @Override
    public void print() {
        super.print();
        System.out.print(position + methods.Setw(position) + courses + methods.Setw(courses));
    }public int Edit() {
            int i= super.Edit();
            if (i==1)return 1;
            if (i==5) {
                this.position = sc.next();
                return 1;
            }else if(i==6){this.courses=sc.next();
                return 1;
            }else return 0;}
    }


