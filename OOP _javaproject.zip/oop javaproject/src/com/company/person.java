package com.company;
import java.util.ArrayList;
import java.util.Scanner;

public  abstract class person {
    private String firstname;
    private String secondname;
    private int age;
    private int id;
Scanner sc=new Scanner(System.in
);

    public String getSecondname() {
        return secondname;
    }

    public void setSecondname(String secondname) {
        this.secondname = secondname;
    }

    public person(){
     this.firstname=null;
        this.age=0;
        this.id=0;
    }
    public person(String name,String name2,int id,int age )
    {
        this.id=id;
        this.age=age;
        this.firstname=name;
        this.secondname=name2;
    }
    public int getAge() {
        return age;
    }
    public int getId() {
        return id;
    }
    public String getName() {
        return firstname;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public void setId(int id) {
        this.id = id;
    }
    public void setName(String name) {
        this.firstname = name;
    }
public void print()
{
String x=String.valueOf(id);
String y=String.valueOf(age);
    System.out.print(id+methods.Setw(x)+firstname+" "+secondname+methods.Setw(secondname+firstname)+age+methods.Setw(y));
}
public int Edit(){
        System.out.println("what you want to edit? 1 or 2 or 3 ....etc");
        print();
        System.out.println("");
        int i=sc.nextInt();
        if(i==1) {
            this.id = sc.nextInt();
            return 1;
        }else if(i==2) {
            this.firstname = sc.next();
            this.secondname=sc.next();
            return 1;
        }else if(i==3)

        {   this.age= sc.nextInt();
            return 1;
}else return i;
    }public int display2(double x,int key)
    {if (key==1) {
        if (x == age)
            print();
        return key;
    }   else return key;
    }
}

