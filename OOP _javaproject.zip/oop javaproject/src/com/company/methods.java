package com.company;

import java.util.Scanner;

public class methods {
    Scanner b=new Scanner(System.in);
 public static int search(ArraysOfClasses arr,int key) {
      Scanner sc=new Scanner(System.in);
      boolean x=false;
      switch (key) {
          case 1: {
              System.out.println("if you want to search by name press 1\n2 by id\n3 by depart\n4 by position");
              int i = sc.nextInt();
              if (i == 1) {
                  System.out.println("enter the name ");
                  String s = "0";
                  String r="0";
                  r=sc.next();
                  s = sc.next();
                  for (int j = 1; j < arr.administrators.size(); j++) {
                      if (arr.administrators.get(j).getName().equalsIgnoreCase(s)&&arr.administrators.get(j).getSecondname().equalsIgnoreCase(r)) {
                          x = false;
                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              }
              if (i == 2) {
                  System.out.println("enter the id ");
                  int s = 0;
                  s = sc.nextInt();
                  for (int j = 1; j < arr.administrators.size(); j++) {
                      if (arr.administrators.get(j).getId() == s) {
                          x = false;
                          display(arr.administrators.get(j));
                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              }
              if (i == 3) {
                  System.out.println("enter the depart ");
                  String s = "0";
                  s = sc.next();
                  for (int j = 1; j < arr.administrators.size(); j++) {
                      if (arr.administrators.get(j).getDepart().equalsIgnoreCase(s) ) {
                          x = false;
                          display(arr.administrators.get(j));
                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              }
              if (i == 4) {
                  System.out.println("enter the position ");
                  String s = "0";
                  s = sc.next();
                  for (int j = 1; j < arr.administrators.size(); j++) {
                      if (arr.administrators.get(j).getPosition().equalsIgnoreCase(s) ) {
                          x = false;
                          display(arr.administrators.get(j));
                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              } else {
                  System.out.println("wrong value");
           return 0;   }
          } case 2:{
              System.out.println("if you want to search by name press 1\n2 by id");
              int i = sc.nextInt();
              if (i == 1) {
                  System.out.println("enter the name ");
                  String s = "0";
                  String r="0";
                  r=sc.next();
                  s = sc.next();
                  for (int j = 1; j < arr.doctors.size(); j++) {
                      if (arr.doctors.get(j).getName().equalsIgnoreCase(s)&&arr.doctors.get(j).getSecondname().equalsIgnoreCase(r) ) {
                          x = false;
                          display(arr.doctors.get(j));
                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              }
              if (i == 2) {
                  System.out.println("enter the id ");
                  int s = 0;
                  s = sc.nextInt();
                  for (int j = 1; j < arr.doctors.size(); j++) {
                      if (arr.doctors.get(j).getId() == s) {
                          x = false;
                          display(arr.doctors.get(j));
                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              } else {
                  System.out.println("wrong value");
                  return 0;   }
          } case 3:{
              System.out.println("if you want to search by \nname press 1\n2 by id\n3 courses");
              int i = sc.nextInt();
              if (i == 1) {
                  System.out.println("enter the name ");
                  String s = "0";
                  String r="0";
                  r=sc.next();
                  s = sc.next();
                  for (int j = 1; j < arr.technicans.size(); j++) {
                      if (arr.technicans.get(j).getName().equalsIgnoreCase(s)&&arr.technicans.get(j).getSecondname().equalsIgnoreCase(r) ) {
                          x = false;
                          display(arr.technicans.get(j));
                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              }
              if (i == 2) {
                  System.out.println("enter the id ");
                  int s = 0;
                  s = sc.nextInt();
                  for (int j = 1; j < arr.technicans.size(); j++) {
                      if (arr.technicans.get(j).getId() == s) {

                          x = false;
                          display(arr.technicans.get(j));
                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              }
              if (i == 3) {
                  System.out.println("enter the depart ");
                  String s = "0";
                  s = sc.next();
                  for (int j = 1; j < arr.technicans.size(); j++) {
                      if (arr.technicans.get(j).getDepart().equalsIgnoreCase(s) ) {
                          x = false;
                          display(arr.technicans.get(j));

                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              }
               else {
                  System.out.println("wrong value");
                  return 0;   }
          } case 4:{
              System.out.println("if you want to search by name press 1\n2 by id\n3 by depart");
              int i = sc.nextInt();
              if (i == 1) {
                  System.out.println("enter the name ");
                  String s = "0";
                  String r="0";
                  r=sc.next();
                  s = sc.next();
                  for (int j = 1; j < arr.employees.size(); j++) {
                      if (arr.employees.get(j).getName().equalsIgnoreCase(s)&&arr.employees.get(j).getSecondname().equalsIgnoreCase(r) ) {
                          x = false;
                          display(arr.employees.get(j));

                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              }
              if (i == 2) {
                  System.out.println("enter the id ");
                  int s = 0;
                  s = sc.nextInt();
                  for (int j = 1; j < arr.employees.size(); j++) {
                      if (arr.employees.get(j).getId() == s) {
                          x = false;
                          display(arr.employees.get(j));

                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              }
              if (i == 3) {
                  System.out.println("enter the depart ");
                  String s = "0";
                  s = sc.next();
                  for (int j = 1; j < arr.employees.size(); j++) {
                      if (arr.employees.get(j).getDepart() == s) {
                          x = false;
                          display(arr.employees.get(j));

                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              }
             else {
                  System.out.println("wrong value");
                  return 0;   }
          } case 5:{
              System.out.println("if you want to search by\nname press 1\n2 by id");
              int i = sc.nextInt();
              if (i == 1) {
                  System.out.println("enter the name ");
                  String s = "0";
                  String r="0";
                  r=sc.next();
                  s = sc.next();
                  for (int j = 1; j < arr.students.size(); j++) {
                      String f=arr.students.get(j).getName();
                      String h=arr.students.get(j).getSecondname();
                      if (f.equalsIgnoreCase(s)&&h.equalsIgnoreCase(r)) {
                          x = false;
                          display(arr.students.get(j));
                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              }
              if (i == 2) {
                  System.out.println("enter the id");
                  int s = 0;
                  s = sc.nextInt();
                  for (int j = 0; j < arr.students.size(); j++) {
                      if (arr.students.get(j).getId() == s) {
                          x = false;
                          display(arr.students.get(j));

                          return j;
                      }
                  }
                  if (!x) {
                      System.out.println("not found");
                      return 0;
                  }
              }
              else {
                  System.out.println("wrong value");
                  return 0;   }
          }
      }
  return 0;}
    public static void display(person a) {
        a.print();
        System.out.println("");
    }

    public static void add(ArraysOfClasses arr, int key) {
//arr.students.r
        Scanner sc = new Scanner(System.in);
        double gpa;
        int level;
        String name1,name2, depart, course, position;
        int id, age;
        double salary;

        switch (key) {
            case 5: {
                ////x , level,name,age,id,depart
                System.out.println("Enter the student name ");
                name1 = sc.next();
                name2=sc.next();
                System.out.println("Enter the student age ");
                age = sc.nextInt();
                System.out.println("Enter the student GPA ");
                gpa = sc.nextDouble();
                System.out.println("Enter the student Department ");
                depart = sc.next();
                System.out.println("Enter the student level ");
                level = sc.nextInt();
                id = arr.students.size() + 1;
                arr.students.add(new student(level, name1,name2, depart, gpa, age, id));
                break;
            }
            case 2: {
                ////x , level,name,age,id,depart
                System.out.println("Enter the Doctor name ");
                name1 = sc.next();
                name2=sc.next();
                id = 1000 * arr.doctors.size() + 1;
                System.out.println("Enter the Doctor age ");
                age = sc.nextInt();
                System.out.println("Enter the Doctor Department ");
                depart = sc.next();
                System.out.println("Enter the Doctor level ");
                level = sc.nextInt();
                System.out.println("Enter the Doctor course ");
                course = sc.next();
                arr.doctors.add(new doctor(name1,name2, id, age, level, course));

                break;
            }
            case 3: {
                ////x , level,name,age,id,depart
//               String name, int id, int age, String depart, String courses
                System.out.println("Enter the Technical name ");
                name1 = sc.next();
                name2 =sc.next();
                id = 2000 * arr.technicans.size() + 1;
                System.out.println("Enter the Technical age ");
                age = sc.nextInt();
                System.out.println("Enter the Technical Department ");
                depart = sc.next();
                System.out.println("Enter the Technical course ");
                course = sc.next();
                arr.technicans.add(new technicans(name1,name2, id, age, depart, course));

                break;
            }
            case 1: {
                ////x , level,name,age,id,depart
//               String name, int id, int age, String depart, String position, String courses
                System.out.println("Enter the Administrators name ");
                name1 = sc.next();
                name2=sc.next();
                id = 3000 * arr.administrators.size() + 1;
                System.out.println("Enter the Administrators age ");
                age = sc.nextInt();
                System.out.println("Enter the Administrators Department ");
                depart = sc.next();
                System.out.println("Enter the Administrators position ");
                position = sc.next();
                System.out.println("Enter the Administrators course ");
                course = sc.next();
                arr.administrators.add(new administrators(name1,name2, id, age, depart, position, course));
                break;
            }
            case 4: {
                ////x , level,name,age,id,depart
//               String name, int id, int age, String depart
                System.out.println("Enter the employee name ");
                name1 = sc.next();
                name2=sc.next();
                System.out.println("Enter the employee ID ");
                id = sc.nextInt();
                System.out.println("Enter the employee age ");
                age = sc.nextInt();
                System.out.println("Enter the employee Department ");
                depart = sc.next();
                arr.employees.add(new employee(name1,name2, id, age, depart));
                break;
            }
        }
    }

    public static int remove(ArraysOfClasses arr, int key, int index) {
        Scanner sc = new Scanner(System.in);
        int i = 1;
        boolean x = false;
        switch (key) {
            case 1: {
                while (i == 1 && index != 0) {
                    if (!x) {
                        System.out.println("choose 1 of you sure,2 if you dont,3 if you wants to back step ,0to end");
                        i = sc.nextInt();
                    }
                    if (i == 1 && !x) {
                        arr.administrators.remove(index);
                        System.out.println("if you want to delete another one press 1,press 2 to return to the back step,and 0 if you wants to end ");
                        if (i == 1) {
                            index = search(arr, key);
                            x = false;
                        } else if (i == 2) return 2;
                        else if (i == 0) return 0;
                        else System.out.println("you input  wrong value ");
                    } else if (i == 2 || (i == 1 && x)) {
                        System.out.println("if you want to delete another one press 1,press 2 to return to the back step,press 0 if you want to end");
                        i = sc.nextInt();
                        if (i == 1) {
                            search(arr, key);
                            x = false;
                        } else if (i == 2) return 2;
                        else if (i == 0) return 0;
                    } else if (i == 3) return 2;
                    else if (i == 0) return 0;
                    else {
                        System.out.println("you input wrong value");
                        System.out.print(" input a valid value");
                        x = true;
                    }
                }
                break;
            }
            case 2: {
                while (i == 1 && index != 0) {
                    if (!x) {
                        System.out.println("choose 1 of you sure,2 if you dont,3 if you wants to back step ,0to end");
                        i = sc.nextInt();
                    }
                    if (i == 1 && !x) {
                        arr.doctors.remove(index);
                        System.out.println("if you want to delete another one press 1,press 2 to return to the back step,and 0 if you wants to end ");
                        if (i == 1) {
                            index = search(arr, key);
                            x = false;
                        } else if (i == 2) return 2;
                        else if (i == 0) return 0;
                        else System.out.println("you input  wrong value ");
                    } else if (i == 2 || (i == 1 && x)) {
                        System.out.println("if you want to delete another one press 1,press 2 to return to the back step,press 0 if you want to end");
                        i = sc.nextInt();
                        if (i == 1) {
                            search(arr, key);
                            x = false;
                        } else if (i == 2) return 2;
                        else if (i == 0) return 0;
                    } else if (i == 3) return 2;
                    else if (i == 0) return 0;
                    else {
                        System.out.println("you input wrong value");
                        System.out.print(" input a valid value");
                        x = true;
                    }
                }
                break;
            }
            case 3: {
                while (i == 1 && index != 0) {
                    if (!x) {
                        System.out.println("choose 1 of you sure,2 if you dont,3 if you wants to back step ,0to end");
                        i = sc.nextInt();
                    }
                    if (i == 1 && !x) {
                        arr.employees.remove(index);
                        System.out.println("if you want to delete another one press 1,press 2 to return to the back step,and 0 if you wants to end ");
                        if (i == 1) {
                            index = search(arr, key);
                            x = false;
                        } else if (i == 2) return 2;
                        else if (i == 0) return 0;
                        else System.out.println("you input  wrong value ");
                    } else if (i == 2 || (i == 1 && x)) {
                        System.out.println("if you want to delete another one press 1,press 2 to return to the back step,press 0 if you want to end");
                        i = sc.nextInt();
                        if (i == 1) {
                            search(arr, key);
                            x = false;
                        } else if (i == 2) return 2;
                        else if (i == 0) return 0;
                    } else if (i == 3) return 2;
                    else if (i == 0) return 0;
                    else {
                        System.out.println("you input wrong value");
                        System.out.print(" input a valid value");
                        x = true;
                    }
                }
                break;
            }
            case 4: {
                while (i == 1 && index != 0) {
                    if (!x) {
                        System.out.println("choose 1 of you sure,2 if you dont,3 if you wants to back step ,0to end");
                        i = sc.nextInt();
                    }
                    if (i == 1 && !x) {
                        arr.employees.remove(index);
                        System.out.println("if you want to delete another one press 1,press 2 to return to the back step,and 0 if you wants to end ");
                        if (i == 1) {
                            index = search(arr, key);
                            x = false;
                        } else if (i == 2) return 2;
                        else if (i == 0) return 0;
                        else System.out.println("you input  wrong value ");
                    } else if (i == 2 || (i == 1 && x)) {
                        System.out.println("if you want to delete another one press 1,press 2 to return to the back step,press 0 if you want to end");
                        i = sc.nextInt();
                        if (i == 1) {
                            search(arr, key);
                            x = false;
                        } else if (i == 2) return 2;
                        else if (i == 0) return 0;
                    } else if (i == 3) return 2;
                    else if (i == 0) return 0;
                    else {
                        System.out.println("you input wrong value");
                        System.out.print(" input a valid value");
                        x = true;
                    }
                }
                break;
            }
            case 5: {
                while (i == 1 && index != 0) {
                    if (!x) {
                        System.out.println("choose 1 of you sure,2 if you dont,3 if you wants to back step ,0to end");
                        i = sc.nextInt();
                    }
                    if (i == 1 && !x) {
                        arr.students.remove(index);
                        System.out.println("if you want to delete another one press 1,press 2 to return to the back step,and 0 if you wants to end ");
                       i=sc.nextInt();
                        if (i == 1) {
                            index = search(arr, key);
                            x = false;
                        } else if (i == 2) return 2;
                        else if (i == 0) return 0;
                        else System.out.println("you input  wrong value ");
                    } else if (i == 2 || (i == 1 && x)) {
                        System.out.println("if you want to delete another one press 1,press 2 to return to the back step,press 0 if you want to end");
                        i = sc.nextInt();
                        if (i == 1) {
                            search(arr, key);
                            x = false;
                        } else if (i == 2) return 2;
                        else if (i == 0) return 0;
                    } else if (i == 3) return 2;
                    else if (i == 0) return 0;
                    else {
                        System.out.println("you input wrong value");
                        System.out.print(" input a valid value");
                        x = true;
                    }
                }
                break;
            }
            default:
                break;
        }
        return 4;
    }

    public static int edit(person a) {
Scanner sc=new Scanner(System.in);
int r=1;

 r=a.Edit();
if (r==0)
{System.out.println("you input wrong value \n if you want to try again press 1\n if you want to back step press 2\n if you wants to end press 0 ");
int i=sc.nextInt();
if(i==1)r= a.Edit();
else if(i==2)return 2;
else if (i==0)return 0;
else return 1;}
while (r==1){
 if(r==1){
    System.out.println("if you want to edit another on same person press 1  if you want to try again press 2\n if you want to back step press 3\n if you wants to end press 0");
  int q=sc.nextInt();
    if(q==1)r= a.Edit();
    else if(q==2)return 1;
    else if(q==3)return 2;
    else if (q==0)return 0;
    else System.out.println("wrong");}
}
return 4;
}
public static String Setw(String x)
{String h=" ";
    for (int i=1;i<25-x.length();i++)
    {h+=" ";
}return h;
}public static void display2(double x,person a)
    {


    }
}

