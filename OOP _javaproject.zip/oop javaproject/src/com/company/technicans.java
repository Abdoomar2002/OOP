package com.company;
    class technicans extends employee {
        private String courses;

        //private  int[] sections=new int [15];
        public String getCourses() {
            return courses;
        }

        public technicans(String name1, String name2, int id, int age, String depart, String courses) {
            super(name1,name2, id, age, depart);
            this.courses = courses;

        }

        public technicans() {
            super();
            this.courses = null;
        }

        public void setCourses(String courses) {
            this.courses = courses;
        }
      public void print() {
        super.print();
        System.out.print(courses + methods.Setw(courses));
    } public int Edit() {
            int i= super.Edit();
            if (i==1)return 1;
            if (i==5) {
                this.courses = sc.next();
                return 1;
            }else return 0;}
    }

